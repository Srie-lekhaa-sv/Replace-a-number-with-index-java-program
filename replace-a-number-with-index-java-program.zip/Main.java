import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner ps = new Scanner(System.in);
		int a[] = new int[10];
		for(int i = 0;i<10;i++){
		    a[i] = ps.nextInt();
		}
		int n = ps.nextInt();
		int k = ps.nextInt();
		for(int i = 0;i<10;i++){
		    if(i==n-1){
		        a[i] = k;
		    }
		    System.out.println(a[i]);
		}
	}
}
